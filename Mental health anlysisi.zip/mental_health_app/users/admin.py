from django.contrib import admin
from .models import Message

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ('sender', 'receiver', 'text', 'timestamp', 'is_group_message')
    search_fields = ('sender__email', 'receiver__email', 'text')
