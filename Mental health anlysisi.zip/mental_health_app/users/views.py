# users/views.py
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from .forms import *

def base(request):
    return render(request, 'base.html')

# Signup view - handle user registration
from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import CustomUserCreationForm

def signup_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('dashboard')  # Redirect to dashboard after signup
        else:
            # If form is not valid, it will pass validation errors back to the template
            return render(request, 'registration/signup.html', {'form': form})
    else:
        form = CustomUserCreationForm()
    
    # If the form is accessed via GET (for example, on initial page load)
    return render(request, 'registration/signup.html', {'form': form})


# Handle user logout
def logout_view(request):
    logout(request)
    return redirect('login')

# profile
@login_required
def profile_view(request):
    return render(request, 'account/profile.html', {'user': request.user})


from django.contrib.auth.forms import UserChangeForm

# @login_required
# def edit_profile(request):
#     if request.method == 'POST':
#         form = UserChangeForm(request.POST, instance=request.user)
#         if form.is_valid():
#             form.save()
#             return redirect('profile')
#     else:
#         form = UserChangeForm(instance=request.user)
#     return render(request, 'account/edit_profile.html', {'form': form})

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import ProfileForm

@login_required
def edit_profile(request):
    user = request.user  # Get the current logged-in user

    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=user)  # Pre-fill the form with user's current data
        if form.is_valid():
            form.save()  # Save the updated data to the database
            return redirect('profile')  # Redirect to profile page (or dashboard, etc.)
    else:
        form = ProfileForm(instance=user)  # Display the form with user's current data

    return render(request, 'account/edit_profile.html', {'form': form})


# Unified dashboard view based on the user's role
from .models import HealthcareTaker
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import render
from .models import HealthcareTaker, GuardianRequest, MedicationAssignment, ActivityAssignment
@login_required
def dashboard_view(request):
    caretaker_assigned = None
    guardian_assigned = None
    patient_assignments = None
    patients_info = []

    if request.user.role == 'patient':
        try:
            # Get assigned caretaker
            caretaker_relation = HealthcareTaker.objects.get(patient=request.user)
            caretaker_assigned = caretaker_relation.healthcare_taker
        except HealthcareTaker.DoesNotExist:
            caretaker_assigned = None

        try:
            # Get the accepted guardian request
            guardian_request = GuardianRequest.objects.get(patient=request.user, status='accepted')
            guardian_assigned = guardian_request.guardian  # Get the guardian directly
        except GuardianRequest.DoesNotExist:
            guardian_assigned = None

    elif request.user.role == 'guardian':
        # Get the patients assigned to the guardian (check the HealthcareTaker model)
        patient_assignments = HealthcareTaker.objects.filter(healthcare_taker=request.user).select_related('patient')
        
        # Check if patient assignments exist
        if patient_assignments.exists():
            # Loop through each patient and fetch the prediction status
            for assignment in patient_assignments:
                patient = assignment.patient
                prediction_status = PatientPredictionStatus.objects.filter(patient=patient).first()
                patients_info.append({
                    'patient': patient,
                    'prediction': prediction_status.prediction if prediction_status else 'No Prediction',
                    'status': prediction_status.prediction.lower() if prediction_status else 'no prediction'
                })
        else:
            print(f"No patients assigned to {request.user.name}.")

    elif request.user.role == 'provider':
        # Get the patients assigned to the healthcare provider
        patient_assignments = HealthcareTaker.objects.filter(healthcare_taker=request.user).select_related('patient')

        # Fetch the accepted guardians for each patient
        for assignment in patient_assignments:
            guardian = assignment.patient.guardian_requests.filter(status='accepted').first()
            assignment.guardian_assigned = guardian.guardian if guardian else None

    return render(request, 'users/dashboard.html', {
        'user': request.user,
        'caretaker_assigned': caretaker_assigned,
        'guardian_assigned': guardian_assigned,
        'patient_assignments': patient_assignments,
        'patients_info': patients_info if request.user.role == 'guardian' else None,
    })

# message 
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.conf import settings
from .models import CustomUser, Message  # Make sure Message uses AUTH_USER_MODEL
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import CustomUser, Message

from django.contrib.auth import get_user_model

@login_required
def user_list_view(request):
    users = get_user_model().objects.exclude(id=request.user.id)  
    return render(request, 'users/user_list.html', {'users': users})


@login_required
def chat_view_by_id(request, user_id):
    other_user = get_object_or_404(CustomUser, id=user_id)
    messages = Message.objects.filter(
        (Q(sender=request.user) & Q(receiver=other_user)) |
        (Q(sender=other_user) & Q(receiver=request.user))
    ).order_by('timestamp')

    if request.method == 'POST':
        text = request.POST.get('text')
        image = request.FILES.get('image')
        Message.objects.create(sender=request.user, receiver=other_user, text=text, image=image)
        return redirect('chat', user_id=other_user.id)  # ✅ Corrected: use user_id instead of username

    return render(request, 'users/chat.html', {
        'messages': messages,
        'receiver': other_user
    })


# medical
from django.shortcuts import render, redirect
from .models import MentalHealthAssessment
from .utils import predict_mental_health

from django.shortcuts import render, redirect
from .models import *
from .utils import predict_mental_health, get_random_questions

def assess_mental_health(request):
    if request.method == 'POST':
        emoji_responses = []
        for i in range(1, 6):  # 5 questions
            emoji_response = int(request.POST.get(f'q{i}'))
            emoji_responses.append(emoji_response)

        # You can average the responses or process them differently
        average_response = round(sum(emoji_responses) / len(emoji_responses))

        result = predict_mental_health(average_response)

        assessment = MentalHealthAssessment.objects.create(
            user=request.user,
            emoji_response=average_response,
            prediction=result['prediction'],
            recommendation=result['recommendation'],
            suggestions=result['suggestions'],
            helpline=result['helpline'],
        )
        PatientPredictionStatus.update_patient_prediction(request.user)
        return redirect('assessment_history')

    questions = get_random_questions()
    return render(request, 'health/assess.html', {'questions': questions})


def assessment_history(request):
    assessments = MentalHealthAssessment.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'health/history.html', {'assessments': assessments})


# assignment
# 
# 
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import CustomUser, HealthcareTaker

from django.contrib.auth.decorators import login_required

@login_required
def available_caretakers_list(request):
    if not request.user.is_authenticated or request.user.role != 'patient':
        messages.error(request, "You must be logged in as a patient to assign a healthcare taker.")
        return redirect('login')  # Redirect to login page or home

    # Find providers (role = 'provider') who are NOT assigned
    assigned_caretakers_ids = HealthcareTaker.objects.values_list('healthcare_taker_id', flat=True)
    available_caretakers = CustomUser.objects.filter(role='provider').exclude(id__in=assigned_caretakers_ids)

    return render(request, 'health/available_caretakers.html', {'caretakers': available_caretakers})

@login_required
def assign_healthcare_taker(request, caretaker_id):
    if not request.user.is_authenticated or request.user.role != 'patient':
        messages.error(request, "You must be logged in as a patient to assign a healthcare taker.")
        return redirect('login')

    if HealthcareTaker.objects.filter(patient=request.user).exists():
        messages.error(request, "You already have a healthcare taker assigned.")
        return redirect('dashboard')

    caretaker = get_object_or_404(CustomUser, id=caretaker_id, role='provider')

    if HealthcareTaker.objects.filter(healthcare_taker=caretaker).exists():
        messages.error(request, "This caretaker is already assigned to a patient.")
        return redirect('available_caretakers_list')

    HealthcareTaker.objects.create(patient=request.user, healthcare_taker=caretaker)
    messages.success(request, f"{caretaker.name} has been assigned as your healthcare taker.")
    return redirect('dashboard')

# guardian
from django.core.mail import send_mail
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import CustomUser, GuardianRequest, HealthcareTaker

from django.conf import settings
from django.contrib.auth.decorators import login_required

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import CustomUser


from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages

from .models import CustomUser, GuardianRequest

from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
from django.shortcuts import render, redirect
from .models import GuardianRequest, CustomUser

from django.core.mail import send_mail
from django.conf import settings

def send_invitation_email(guardian_email, patient_name):
    subject = f"Invitation for Guardian of {patient_name}"
    message = f"Hello, you are invited to be the guardian for {patient_name}. Please accept or decline the request."
    from_email = settings.DEFAULT_FROM_EMAIL
    recipient_list = [guardian_email]
    
    send_mail(subject, message, from_email, recipient_list)


@login_required
def invite_guardian(request, patient_id):
    patient = get_object_or_404(CustomUser, id=patient_id, role='patient')
    
    if request.user.role != 'provider':
        messages.error(request, "You do not have permission to invite guardians.")
        return redirect('dashboard')

    available_guardians = CustomUser.objects.filter(role='guardian')

    if request.method == 'POST':
        guardian_id = request.POST.get('guardian_id')
        guardian = get_object_or_404(CustomUser, id=guardian_id, role='guardian')

        # Check if the patient already has an accepted guardian
        existing_guardian = GuardianRequest.objects.filter(patient=patient, status='accepted').first()
        if existing_guardian:
            messages.error(request, f"{patient.name} already has a guardian assigned.")
            return redirect('dashboard')

        # Create a guardian request
        GuardianRequest.objects.create(
            patient=patient,
            guardian=guardian,
            healthcare_provider=request.user,
            status='pending',
            is_accepted=False
        )

        # Send email to the guardian
        subject = f"Invitation to be a Guardian for {patient.name}"
        message = f"Hello {guardian.name},\n\nYou have been invited to be a guardian for {patient.name}. Please accept or decline the request from the provider."
        from_email = settings.DEFAULT_FROM_EMAIL
        recipient_list = [guardian.email]
        send_mail(subject, message, from_email, recipient_list)

        messages.success(request, f"Invitation sent to {guardian.name}!")
        return redirect('dashboard')

    context = {
        'patient': patient,
        'available_guardians': available_guardians,
    }
    return render(request, 'health/invite_guardian.html', context)


@login_required
def guardian_requests_list(request):
    guardian = request.user
    if guardian.role != 'guardian':
        messages.error(request, "Only guardians can access this page.")
        return redirect('dashboard')

    requests = GuardianRequest.objects.filter(guardian=guardian, status='pending')
    return render(request, 'health/guardian_requests_list.html', {'requests': requests})

@login_required
def respond_guardian_request(request, request_id, response):
    guardian = request.user
    guardian_request = get_object_or_404(GuardianRequest, id=request_id, guardian=guardian)

    if response == 'accept':
        # Accept the request
        guardian_request.status = 'accepted'
        guardian_request.is_accepted = True
        guardian_request.save()

        # Assign the guardian to the patient
        HealthcareTaker.assign_guardian(guardian_request.patient, guardian)

        messages.success(request, f"You have accepted the guardian request for {guardian_request.patient.name}.")
    elif response == 'deny':
        guardian_request.status = 'rejected'
        guardian_request.save()
        messages.info(request, f"You have denied the guardian request for {guardian_request.patient.name}.")

    return redirect('guardian_requests_list')


from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect
from .models import CustomUser, MedicationAssignment, ActivityAssignment, Recommendation
from .forms import MedicationAssignmentForm, ActivityAssignmentForm, RecommendationForm

@login_required
def assign_medication(request, patient_id):
    patient = get_object_or_404(CustomUser, id=patient_id)

    if request.method == 'POST':
        form = MedicationAssignmentForm(request.POST)
        if form.is_valid():
            medication = form.save(commit=False)
            medication.patient = patient
            medication.guardian = request.user
            medication.save()
            messages.success(request, f'Medication "{medication.medication_name}" assigned successfully.')
            return redirect('guardian_patient_list')
    else:
        form = MedicationAssignmentForm()

    context = {
        'form': form,
        'patient': patient,
    }
    return render(request, 'guardian/assign_medication.html', context)


@login_required
def assign_activity(request, patient_id):
    patient = get_object_or_404(CustomUser, id=patient_id)

    if request.method == 'POST':
        form = ActivityAssignmentForm(request.POST)
        if form.is_valid():
            activity = form.save(commit=False)
            activity.patient = patient
            activity.guardian = request.user
            activity.save()
            messages.success(request, f'Activity "{activity.activity_name}" assigned successfully.')
            return redirect('guardian_patient_list')
    else:
        form = ActivityAssignmentForm()

    context = {
        'form': form,
        'patient': patient,
    }
    return render(request, 'guardian/assign_activity.html', context)


@login_required
def add_recommendation(request, patient_id):
    patient = get_object_or_404(CustomUser, id=patient_id)

    if request.method == 'POST':
        form = RecommendationForm(request.POST)
        if form.is_valid():
            recommendation = form.save(commit=False)
            recommendation.patient = patient
            recommendation.created_by = request.user
            recommendation.save()
            messages.success(request, f'Recommendation "{recommendation.title}" added successfully.')
            return redirect('guardian_patient_list')
    else:
        form = RecommendationForm()

    context = {
        'form': form,
        'patient': patient,
    }
    return render(request, 'guardian/add_recommendation.html', context)


# users/views.py
# users/views.py

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import CustomUser, HealthcareTaker, MedicationAssignment, ActivityAssignment, Recommendation, PatientPredictionStatus, GuardianRequest, MentalHealthAssessment
from .forms import MedicationAssignmentForm, ActivityAssignmentForm, RecommendationForm
from django.db.models import Q

@login_required
def guardian_patient_list(request):
    guardian = request.user

    # 1. Correct way: Get all accepted GuardianRequests for this guardian
    assigned_requests = GuardianRequest.objects.filter(guardian=guardian, status='accepted')
    assigned_patients = assigned_requests.values_list('patient', flat=True)

    # 2. Patient search
    search_query = request.GET.get('search', '')
    if search_query:
        patients = CustomUser.objects.filter(
            Q(id__in=assigned_patients),
            Q(name__icontains=search_query) | Q(email__icontains=search_query)
        )
    else:
        patients = CustomUser.objects.filter(id__in=assigned_patients)

    # 3. For each patient, fetch their caretaker and mental health prediction
    patient_data = []
    for patient in patients:
        caretaker_relation = assigned_requests.filter(patient=patient).first()
        caretaker = caretaker_relation.healthcare_provider if caretaker_relation else None

        prediction_status = PatientPredictionStatus.objects.filter(patient=patient).first()
        mental_health_prediction = prediction_status.prediction if prediction_status else 'Unknown'

        # Decide card color based on mental health prediction
        card_color = get_card_color(mental_health_prediction)

        patient_data.append({
            'patient': patient,
            'caretaker': caretaker,
            'prediction': mental_health_prediction,
            'card_color': card_color,
        })

    # Forms to assign medication, activity, recommendation
    medication_form = MedicationAssignmentForm()
    activity_form = ActivityAssignmentForm()
    recommendation_form = RecommendationForm()

    resources = get_tips_and_resources()

    context = {
        'patient_data': patient_data,
        'medication_form': medication_form,
        'activity_form': activity_form,
        'recommendation_form': recommendation_form,
        'resources': resources,
        'search_query': search_query,
    }
    return render(request, 'guardian/patients_list.html', context)


def get_card_color(prediction):
    """Return Bootstrap color classes based on mental health prediction."""
    if prediction in ['😄 Very Happy', '🙂 Happy']:
        return 'success'  # Green
    elif prediction == '😐 Neutral':
        return 'warning'  # Yellow
    elif prediction in ['😟 Sad', '😢 Very Sad']:
        return 'danger'   # Red
    else:
        return 'secondary'  # Grey


def get_tips_and_resources():
    """Return tips based on patient prediction status."""
    # This can be loaded from the database or static content
    return {
        'Very Happy': [
            "Encourage them to maintain their healthy routines.",
            "Celebrate their achievements."
        ],
        'Happy': [
            "Keep communication open and positive.",
            "Encourage continuous self-care habits."
        ],
        'Neutral': [
            "Offer to listen without judgment.",
            "Suggest light activities together."
        ],
        'Sad': [
            "Encourage professional help if needed.",
            "Be patient and understanding."
        ],
        'Very Sad': [
            "Stay close; consistent support is crucial.",
            "Help them connect with a mental health professional immediately."
        ],
        'Unknown': [
            "Gently encourage completing an assessment for better support."
        ]
    }

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import MedicationAssignment, ActivityAssignment, Recommendation
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import MedicationAssignment, ActivityAssignment, Recommendation, CustomUser


from django.shortcuts import render
from .models import MedicationAssignment, ActivityAssignment, Recommendation
from django.contrib.auth.decorators import login_required

@login_required
def view_patient_assignments(request):
    user = request.user
    
    # Fetch assignments
    medications = MedicationAssignment.objects.filter(patient=user)
    activities = ActivityAssignment.objects.filter(patient=user)
    recommendations = Recommendation.objects.filter(patient=user)

    context = {
        'medications': medications,
        'activities': activities,
        'recommendations': recommendations,
    }
    return render(request, 'users/patient_caretaker_view.html', context)
