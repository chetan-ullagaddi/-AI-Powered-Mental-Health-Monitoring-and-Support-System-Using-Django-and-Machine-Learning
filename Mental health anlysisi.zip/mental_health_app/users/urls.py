# users/urls.py
from django.urls import path
from django.contrib.auth import views as auth_views
from .views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', base, name='base'),
    
    path('signup/', signup_view, name='signup'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    
    path('profile/', login_required(profile_view), name='profile'),
    path('profile/edit/', edit_profile, name='edit_profile'),
    
    path('password/', auth_views.PasswordChangeView.as_view(template_name='registration/change_password.html', success_url='/dashboard/'), name='change_password'),


    path('dashboard/', dashboard_view, name='dashboard'),
    path('messages/', user_list_view, name='user_list'),
    path('messages/<int:user_id>/', chat_view_by_id, name='chat'),

    path('assess/', assess_mental_health, name='assess_mental_health'),
    path('history/', assessment_history, name='assessment_history'),

    path('caretakers/', available_caretakers_list, name='available_caretakers_list'),
    path('assign-caretaker/<int:caretaker_id>/', assign_healthcare_taker, name='assign_healthcare_taker'),
    

    path('invite-guardian/<int:patient_id>/', invite_guardian, name='invite_guardian'),
    path('guardian-requests/', guardian_requests_list, name='guardian_requests_list'),
    path('respond-guardian-request/<int:request_id>/<str:response>/', respond_guardian_request, name='respond_guardian_request'),
    path('add-recommendation/<int:patient_id>/', add_recommendation, name='add_recommendation'),

    path('guardian_patient_list/', guardian_patient_list, name='guardian_patient_list'),

    # ADD THESE 👇
    path('assign_medication/<int:patient_id>/', assign_medication, name='assign_medication'),
    path('assign_activity/<int:patient_id>/', assign_activity, name='assign_activity'),
    path('add_recommendation/<int:patient_id>/', add_recommendation, name='add_recommendation'),
    
    path('patient_caretaker_view/', view_patient_assignments, name='patient_caretaker_view'),
    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

