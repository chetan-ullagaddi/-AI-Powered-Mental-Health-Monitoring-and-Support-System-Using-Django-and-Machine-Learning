# users/models.py
from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('patient', 'Patient'),
        ('guardian', 'Guardian'),
        ('provider', 'Healthcare Provider'),
    ]
    
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    contact = models.CharField(max_length=15, blank=True)
    age = models.PositiveIntegerField(null=True, blank=True)
    gender = models.CharField(max_length=10, choices=[
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other')
    ], blank=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'name', 'role']

    def __str__(self):
        return f"{self.name} ({self.role})"

from django.conf import settings

class Message(models.Model):
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_messages')
    receiver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='received_messages', null=True, blank=True)
    text = models.TextField(blank=True)
    image = models.ImageField(upload_to='messages/', blank=True, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_group_message = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sender} to {self.receiver or 'Group'}"

from django.db import models
from users.models import CustomUser

class MentalHealthAssessment(models.Model):
    EMOJI_CHOICES = [
        (1, '😄 Very Happy'),
        (2, '🙂 Happy'),
        (3, '😐 Neutral'),
        (4, '😟 Sad'),
        (5, '😢 Very Sad'),
    ]

    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    emoji_response = models.IntegerField(choices=EMOJI_CHOICES)
    prediction = models.CharField(max_length=100)
    recommendation = models.TextField()
    suggestions = models.TextField()
    helpline = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.name} - {self.created_at.date()}"

# guard
from django.db import models
from django.conf import settings
from users.models import CustomUser

class HealthcareTaker(models.Model):
    """One patient assigns exactly one healthcare taker and vice versa."""
    patient = models.OneToOneField(CustomUser, related_name='assigned_healthcare_taker', on_delete=models.CASCADE)
    healthcare_taker = models.OneToOneField(CustomUser, related_name='assigned_patient', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.healthcare_taker.name} for {self.patient.name}"
    
    @staticmethod
    def assign_guardian(patient, guardian):
        """Assign a guardian to a patient."""
        # Create the assignment of the guardian to the patient
        HealthcareTaker.objects.create(patient=patient, healthcare_taker=guardian)


class GuardianRequest(models.Model):
    """Handles guardian invitation and acceptance flow."""
    patient = models.ForeignKey(CustomUser, related_name='guardian_requests', on_delete=models.CASCADE)
    guardian = models.ForeignKey(CustomUser, related_name='guardian_invitations', on_delete=models.CASCADE)
    healthcare_provider = models.ForeignKey(CustomUser, related_name='guardian_sent_requests', on_delete=models.CASCADE)
    status = models.CharField(
        max_length=10,
        choices=[('pending', 'Pending'), ('accepted', 'Accepted'), ('rejected', 'Rejected')],
        default='pending'
    )
    is_accepted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Request from {self.healthcare_provider.name} to {self.guardian.name} for {self.patient.name}"

class MedicationAssignment(models.Model):
    """Guardian can assign medication after accepting the request."""
    patient = models.ForeignKey(CustomUser, related_name='medications', on_delete=models.CASCADE)
    guardian = models.ForeignKey(CustomUser, related_name='assigned_medications', on_delete=models.CASCADE)
    medication_name = models.CharField(max_length=255, blank=True)
    dosage = models.CharField(max_length=255, blank=True)
    notes = models.TextField(blank=True)
    dosage_instructions = models.TextField(blank=True)
    assigned_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.medication_name} for {self.patient.name}"

class ActivityAssignment(models.Model):
    """Guardian can assign activities to the patient."""
    patient = models.ForeignKey(CustomUser, related_name='activities', on_delete=models.CASCADE)
    guardian = models.ForeignKey(CustomUser, related_name='assigned_activities', on_delete=models.CASCADE)
    activity_name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    assigned_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.activity_name} for {self.patient.name}"

class Recommendation(models.Model):
    """General recommendations - created by guardians or healthcare providers."""
    RECOMMENDATION_TYPE_CHOICES = [
        ('book', 'Book'),
        ('movie', 'Movie'),
        ('activity', 'Activity'),
        ('exercise', 'Exercise'),
    ]

    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    type = models.CharField(max_length=20, choices=RECOMMENDATION_TYPE_CHOICES)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    patient = models.ForeignKey(CustomUser, related_name='recommendations', on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.type})"

class PatientPredictionStatus(models.Model):
    """Stores the latest mental health prediction for each patient."""
    patient = models.OneToOneField(CustomUser, related_name='prediction_status', on_delete=models.CASCADE)
    prediction = models.CharField(max_length=100)  # Same as MentalHealthAssessment.prediction field
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.patient.name} - {self.prediction}"

    @staticmethod
    def update_patient_prediction(patient):
        """Update patient's prediction based on the latest MentalHealthAssessment."""
        latest_assessment = MentalHealthAssessment.objects.filter(user=patient).order_by('-created_at').first()
        if latest_assessment:
            prediction_status, created = PatientPredictionStatus.objects.get_or_create(patient=patient)
            prediction_status.prediction = latest_assessment.prediction
            prediction_status.save()
