import joblib
import numpy as np

from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier

import random

# 25 Mental Health Questions
QUESTIONS = [
    "How often have you felt little interest or pleasure in doing things?",
    "How often have you felt down, depressed, or hopeless?",
    "How often do you have trouble falling asleep or staying asleep?",
    "How often do you feel tired or have little energy?",
    "How often do you have poor appetite or overeating?",
    "How often do you feel bad about yourself?",
    "How often have you had trouble concentrating on things?",
    "How often do you move or speak so slowly that others notice?",
    "How often do you feel restless or fidgety?",
    "How often have you thought you would be better off dead?",
    "How often do you find it hard to relax?",
    "How often do you get easily annoyed or irritable?",
    "How often have you avoided social interactions?",
    "How often do you feel lonely?",
    "How often do you experience mood swings?",
    "How often have you felt worthless?",
    "How often have you experienced panic attacks?",
    "How often do you feel overwhelmed by everyday tasks?",
    "How often do you feel disconnected from reality?",
    "How often have you used alcohol or drugs to feel better?",
    "How often do you have thoughts of self-harm?",
    "How often do you have difficulties in decision making?",
    "How often have you been unable to control your worrying?",
    "How often do you feel that everything is an effort?",
    "How often have you lacked motivation even for basic tasks?"
]

def get_random_questions(num=5):
    return random.sample(QUESTIONS, num)

# Dummy dataset (emoji scale to mental health condition)
# In production, replace this with real-world clinical data
X = np.array([[1], [2], [3], [4], [5]])  # Emoji scale input
y = np.array([0, 1, 2, 3, 4])  # Labels: 0 = very healthy, 4 = severe depression

# Train models
random_forest = RandomForestClassifier()
decision_tree = DecisionTreeClassifier()
xgboost = XGBClassifier(eval_metric='mlogloss', use_label_encoder=False)

random_forest.fit(X, y)
decision_tree.fit(X, y)
xgboost.fit(X, y)

# Save models if needed (optional)
# joblib.dump(random_forest, 'random_forest.pkl')
# joblib.dump(decision_tree, 'decision_tree.pkl')
# joblib.dump(xgboost, 'xgboost.pkl')

def predict_mental_health(emoji_response):
    input_data = np.array([[emoji_response]])
    
    # Use all models and ensemble their outputs
    rf_pred = random_forest.predict(input_data)[0]
    dt_pred = decision_tree.predict(input_data)[0]
    xgb_pred = xgboost.predict(input_data)[0]
    
    # Majority voting
    predictions = [rf_pred, dt_pred, xgb_pred]
    final_prediction = max(set(predictions), key=predictions.count)
    
    condition_mapping = {
        0: "Excellent Mental Health",
        1: "Good Mental Health",
        2: "Average Mental Health",
        3: "Poor Mental Health",
        4: "Severe Mental Health Issues"
    }
    
    recommendation_mapping = {
        0: "Keep up your good work! Maintain your healthy habits.",
        1: "Stay positive! Engage in social and physical activities.",
        2: "Take regular breaks, talk to loved ones, monitor your mood.",
        3: "Consider speaking to a counselor or mental health professional.",
        4: "Seek immediate help. Contact mental health services urgently."
    }
    
    suggestions_mapping = {
        0: "Practice mindfulness, gratitude journaling.",
        1: "Keep a balanced work-life schedule.",
        2: "Meditate, avoid information overload.",
        3: "Reduce screen time, set small goals, rest well.",
        4: "Don't isolate yourself, call a support hotline."
    }
    
    helpline_mapping = {
        0: "N/A",
        1: "N/A",
        2: "Mental Health Support Line: 1800-123-456",
        3: "Counseling Center: 1800-234-567",
        4: "Emergency Helpline: 1800-345-678"
    }
    
    return {
        'prediction': condition_mapping[final_prediction],
        'recommendation': recommendation_mapping[final_prediction],
        'suggestions': suggestions_mapping[final_prediction],
        'helpline': helpline_mapping[final_prediction]
    }
