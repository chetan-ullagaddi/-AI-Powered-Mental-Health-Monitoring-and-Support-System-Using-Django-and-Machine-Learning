from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser

class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'name', 'contact', 'age', 'gender', 'role')
    
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if CustomUser.objects.filter(username=username).exists():
            raise forms.ValidationError("Username is already taken.")
        return username

from django import forms
from .models import CustomUser  # assuming you're using a custom user model

class ProfileForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['name', 'email', 'contact', 'age', 'gender']  # adjust fields as per your model
        widgets = {
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'contact': forms.TextInput(attrs={'class': 'form-control'}),
            'age': forms.NumberInput(attrs={'class': 'form-control'}),
            'gender': forms.Select(attrs={'class': 'form-control'}),
            'name': forms.TextInput(attrs={'class': 'form-control'}),
        }

from django import forms
from .models import MedicationAssignment, ActivityAssignment, Recommendation, PatientPredictionStatus

class BootstrapFormMixin:
    """Mixin to add Bootstrap classes automatically."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            existing_class = field.widget.attrs.get('class', '')
            field.widget.attrs['class'] = existing_class + ' form-control'

class MedicationAssignmentForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = MedicationAssignment
        fields = ['medication_name', 'dosage', 'notes', 'dosage_instructions']


class ActivityAssignmentForm(forms.ModelForm):
    class Meta:
        model = ActivityAssignment
        fields = ['activity_name', 'description']
        widgets = {
            'activity_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter activity name'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Activity description', 'rows': 3}),
        }

class RecommendationForm(forms.ModelForm):
    class Meta:
        model = Recommendation
        fields = ['title', 'description', 'type']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter recommendation title'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Recommendation description', 'rows': 3}),
            'type': forms.Select(attrs={'class': 'form-select'}),
        }

class PatientPredictionStatusForm(forms.ModelForm):
    class Meta:
        model = PatientPredictionStatus
        fields = ['prediction']
        widgets = {
            'prediction': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter updated mental health prediction'}),
        }
